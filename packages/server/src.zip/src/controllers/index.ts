export {router as mediaController} from "./media.controller"
export {router as orderController} from "./order.controller"
export {router as authController} from "./auth.controller"