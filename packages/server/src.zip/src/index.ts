export * as ServerDtos from './dtos';
export * as ServerEntities from './entities';
export {GuitarPartEnumType} from './enums';
export * from './interfaces/satisfies.interface'
export * from './interfaces/entity-without-base.interface'