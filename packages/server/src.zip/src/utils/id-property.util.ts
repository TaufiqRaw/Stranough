// used in entities to define id properties at @Property decorator.
export const idProperty = {type : 'int', unsigned : true};