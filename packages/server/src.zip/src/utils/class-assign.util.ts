export function classAssign(target : any, source : any) {
    return Object.assign(target, source);
}