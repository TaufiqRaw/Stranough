export type PaginationQueryType = {
  page : number,
  limit : number,
}