import {OutputInfo} from 'sharp'

export interface ImageConversionOutput extends OutputInfo {
  filename : string,
} 